## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  message = FALSE,
  warning = FALSE,
  error = FALSE,
  tidy = FALSE,
  cache = FALSE,
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, fig.cap="Fig. 1: LiDAR data collection", out.width = '40%'----
pictFile <- system.file("extdata", "lidar_img_1.png", package = "adaboost")
knitr::include_graphics(pictFile)

## ---- results="hide", warning = FALSE------------------------------------
# Read a .las/.laz file
library(adaboost)
dFile <- system.file("extdata", "lasc04765150.las", package = "adaboost")
dlasOut <- readFile(dFile)
# Extract all the LAS metadata for this file
lasMetadata <- lasSlotExtract(dlasOut, dFile)
# Extract individual components
dataTibble <- lasMetadata["dataTibble"]$dataTibble
dataColName <- lasMetadata["dbColnamesData"]$dbColnamesData
headerTibble <- lasMetadata["headerTibble"]$headerTibble
headerColName <- lasMetadata["dbColnamesHeader"]$dbColnamesHeader

## ---- warning = FALSE----------------------------------------------------
lasMetadata["totalPts"]

## ---- warning = FALSE----------------------------------------------------
lasMetadata["returnNo"]

## ---- warning = FALSE----------------------------------------------------
lasMetadata["noOfReturns"]

## ---- warning = FALSE----------------------------------------------------
lasMetadata["classificationMap"]

## ---- warning = FALSE----------------------------------------------------
lasMetadata["top5Intensity"]

## ------------------------------------------------------------------------
lasSlotPrint(dlasOut)

## ---- results="hide" , warning = FALSE-----------------------------------
# Read the file
gFile <- system.file("extdata", "project.las", package = "adaboost")
glasOut <- readFile(gFile)

## ---- results="hide", out.width = "85%", fig.width= 8, fig.height= 8-----
lasVisualize(glasOut, "plotDem")

## ---- out.width = "85%", fig.width= 8, fig.height= 8---------------------
lasVisualize(glasOut, "plotChm")

## ---- results="hide", out.width = "85%", fig.width= 9, fig.height= 9-----
lasVisualize(glasOut, "plotTreeTop")

## ---- results="hide", out.width = "75%", fig.width= 7, fig.height= 7-----
tFile <- system.file("extdata", "037_HARV_ndvi_crop.tif", package = "adaboost")
tifFile <- processTiff(tFile)$rasterTif

## ---- warning = FALSE----------------------------------------------------
MonetDBLite::monetdblite_shutdown()
loadMonetDB(dataTibble, dataColName, "slotdata" )
MonetDBLite::monetdblite_shutdown()

## ---- warning = FALSE----------------------------------------------------
MonetDBLite::monetdblite_shutdown()
loadMonetDB(headerTibble, headerColName, "slotheader" )
MonetDBLite::monetdblite_shutdown()

## ---- warning = FALSE----------------------------------------------------
scoreOutput <- treeDensityIndex(dlasOut)
scoreOutput["RumpleIndex"]

## ---- eval= FALSE--------------------------------------------------------
#  scoreOutput["densityScore"]

## ---- warning = FALSE----------------------------------------------------
dtreeCoordinates <- scoreOutput["treeCoordinates"]
treeX <- dtreeCoordinates$treeCoordinates$x
treeY <- dtreeCoordinates$treeCoordinates$y
treeZ <- dtreeCoordinates$treeCoordinates$height
treeDensityPlot(treeX, treeY, treeZ)

## ---- warning = FALSE----------------------------------------------------
scoreOutput["treeCount"]

## ---- warning = FALSE----------------------------------------------------
scoreOutput["treeFreq"]

## ---- warning = FALSE----------------------------------------------------
gscoreOutput <- treeDensityIndex(glasOut)
gscoreOutput["RumpleIndex"]

## ------------------------------------------------------------------------
gscoreOutput["densityScore"]

## ---- warning = FALSE----------------------------------------------------
gtreeCoordinates <- gscoreOutput["treeCoordinates"]
gtreeX <- gtreeCoordinates$treeCoordinates$x
gtreeY <- gtreeCoordinates$treeCoordinates$y
gtreeZ <- gtreeCoordinates$treeCoordinates$height
treeDensityPlot(gtreeX, gtreeY, gtreeZ)

## ---- warning = FALSE----------------------------------------------------
gscoreOutput["treeCount"]

## ---- warning = FALSE----------------------------------------------------
gscoreOutput["treeFreq"]

## ---- echo=FALSE, fig.cap="Fig. 1: Example csv file", out.width = '40%'----
pictFile <- system.file("extdata", "lidR_csv.png", package = "adaboost")
knitr::include_graphics(pictFile)

## ------------------------------------------------------------------------
sessionInfo()

